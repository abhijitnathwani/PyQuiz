PyQuiz
PyQuiz is an interactive quiz game built with Python. The aim was to create and application and learn the basics of python GUI programming with TKinter. As I explored Tkinter more, I thought of developing this simplest game.

The PyQuiz opens up with multiple choice questions and increments your score with 5 as you answer correctly in the game and reduces 5 points for every incorrect answer. It also asks you for your confirmation while exiting the application.

Installation

To install PyQuiz! to your system,

`pip install py-quiz`

To run PyQuiz! just fire the command `py-quiz` in your terminal.

Things To-Do:
* ~~Create basic application~~
* ~~Add score counter~~
* ~~Add questions from JSON file.~~
* ~~Create a `pip` installer package~~
* ~~Confirm quit option~~
* Resize Window as per question length. ( If somebody can help me with this, it'll be great!)

Info

PyQuiz is maintained at https://github.com/abhijitnathwani/PyQuiz/
Any questions/suggestions are welcome. Feel free to drop an email: abhijit[dot]nathwani[at]gmail[dot]com or raise and issue with the repo.

